# Caelia Brain Gateway

This server folder is the intended boundary between the avatar and Caelia's real brain.

## Recommended production topology

Browser / Motherboard UI
    |
    v
caeliasystems.com
    |
    v
backend.caeliasystems.com
    |
    +--> Caelia Brain Router
    +--> Permission / Policy Engine
    +--> Memory Service
    +--> Plugin Broker
    +--> Audit Service
    +--> Secrets Vault

The avatar should never receive master credentials.

## Required production controls

- HTTPS only
- authenticated sessions
- role/permission checks server-side
- rate limits
- request validation
- CORS allowlist
- CSRF protection where applicable
- security headers
- structured audit events
- secret vault / environment injection
- dependency scanning
- backups
- health endpoint
- graceful shutdown
